interface jQuery {
  dataTable(options?: any, callback?: Function): any;
}
