import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormsModule,
  Validators
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";

import * as $ from "jquery";

@Component({
  selector: "app-timesheets",
  templateUrl: "./timesheets.component.html",
  styleUrls: ["./timesheets.component.css"]
})
export class TimesheetsComponent implements OnInit {
  constructor(){}
  ngOnInit() {}
   
}
